const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database(":memory:", (err) => {
    if (err) {
        console.error("Database connection error:", err);
        process.exit(1);
    }
    console.log("Connected to in-memory SQLite database");
});

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT,
        is_admin INTEGER
    )`, (err) => {
        if (err) {
            console.error("Table creation error:", err);
            process.exit(1);
        }
        console.log("Users table created");
    });

    db.get(`SELECT * FROM users WHERE username='admin'`, (err, row) => {
        if (err) {
            console.error("Query error:", err);
            return;
        }
        if (!row) {
            db.run(
                `INSERT INTO users (username, password, is_admin)
                 VALUES ('admin', 'verysecurepassword', 1)`,
                (err) => {
                    if (err) {
                        console.error("Insert error:", err);
                    } else {
                        console.log("Admin user created");
                    }
                }
            );
        }
    });
});

module.exports = db;
