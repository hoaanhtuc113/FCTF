const express = require("express");
const bodyParser = require("body-parser");
const db = require("./db");
const path = require("path");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "/"));

app.get("/", (req, res) => {
    res.render("login", { msg: "" });
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const query = `SELECT * FROM users WHERE username='${username}' AND password='${password}' LIMIT 1`;

    console.log("[EXEC]:", query);

    try {
        db.get(query, (err, row) => {
            if (err) {
                console.error("Database query error:", err);
                return res.render("login", { msg: "❌ Invalid credentials" });
            }

            if (!row) return res.render("login", { msg: "❌ Invalid credentials" });

            if (row.is_admin)
                return res.render("flag", { username: row.username });

            res.send(`<h3>Hello ${row.username}, but no admin privilege.</h3>`);
        });
    } catch (error) {
        console.error("Unexpected error:", error);
        return res.render("login", { msg: "❌ Invalid credentials" });
    }

});

app.listen(3000, () => console.log("SQL Injection lab running on :3000"));
